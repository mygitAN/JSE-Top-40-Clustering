"""Validate the retained 123-row retrospective dataset without third-party packages."""
import csv
import json
import math
import statistics
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data/processed/Top40_Retrospective_Model_Inputs_v1.csv'
METHOD = ROOT / 'docs/Top40_Retrospective_Model_Method_v1.json'


def percentile(values, q):
    values = sorted(values)
    index = (len(values)-1)*q
    lo = math.floor(index)
    hi = math.ceil(index)
    return values[lo] + (values[hi]-values[lo])*(index-lo)


def derive_constants(rows):
    train = [r for r in rows if r['decision_date'] == '2025-06-30']
    median = lambda key, flag: statistics.median(float(r[key]) for r in train if r[flag] == 'false')
    yields = [float(r['earnings_yield_raw']) for r in train if r['earnings_yield_raw']]
    return dict(volume=median('average_daily_volume_1y_model', 'volume_imputed'),
                revenue=median('revenue_zar_raw', 'fundamentals_imputed'),
                eps=median('eps_zar_raw', 'fundamentals_imputed'),
                earnings_yield=median('earnings_yield_raw', 'fundamentals_imputed'),
                lower=percentile(yields, .01), upper=percentile(yields, .99))


def validate(data=None, method_path=None):
    with Path(data or DATA).open(newline='', encoding='utf-8') as stream:
        rows = list(csv.DictReader(stream))
    method = json.loads(Path(method_path or METHOD).read_text(encoding='utf-8'))
    derived = derive_constants(rows)
    recorded = dict(volume=method['volume_imputation']['value'],
                    revenue=method['fundamental_imputation']['revenue_zar'],
                    eps=method['fundamental_imputation']['eps_zar'],
                    earnings_yield=method['fundamental_imputation']['earnings_yield'],
                    lower=method['earnings_yield_clipping']['lower'], upper=method['earnings_yield_clipping']['upper'])
    for key in recorded:
        assert math.isclose(derived[key], recorded[key], rel_tol=1e-12, abs_tol=1e-12), ('Derivation mismatch', key, derived[key], recorded[key])
    dates = ['2025-06-30', '2025-12-31', '2026-06-30']
    assert len(rows) == 123, 'All 123 historical observations must be retained'
    assert Counter(r['decision_date'] for r in rows) == dict.fromkeys(dates, 41)
    assert len({(r['decision_date'], r['ticker']) for r in rows}) == 123
    assert len({r['ticker'] for r in rows}) == 43
    membership = {d: {r['ticker'] for r in rows if r['decision_date'] == d} for d in dates}
    assert membership[dates[1]] == (membership[dates[0]] - {'APN'}) | {'GLN'}
    assert membership[dates[2]] == (membership[dates[1]] - {'MNP'}) | {'PAN'}
    assert all('RNI' in membership[d] and 'NPH' in membership[d] for d in dates)
    assert { (r['decision_date'], r['ticker']) for r in rows if r['volume_imputed'] == 'true'} == {(dates[0], 'AGL'), (dates[1], 'AGL')}
    assert { (r['decision_date'], r['ticker']) for r in rows if r['fundamentals_imputed'] == 'true'} == {(d, 'RNI') for d in dates}
    numeric = ['return_1y', 'average_daily_volume_1y_model', 'market_cap_zar', 'beta_1y',
               'shares_outstanding', 'revenue_zar_model', 'eps_zar_model',
               'annualised_volatility_1y', 'dividend_yield', 'earnings_yield_model_clipped', 'close_zar']
    for r in rows:
        assert all(r[flag] in {'true', 'false'} for flag in ['volume_imputed', 'fundamentals_imputed'])
        assert r['sector_label'] and r['membership_evidence'] == 'VERIFIED'
        assert all(math.isfinite(float(r[k])) for k in numeric), (r['ticker'], 'Missing model feature')
        assert math.isclose(float(r['market_cap_zar']), float(r['shares_outstanding']) * float(r['close_zar']), rel_tol=1e-5)
        if r['volume_imputed'] == 'true':
            assert math.isclose(float(r['average_daily_volume_1y_model']), method['volume_imputation']['value'])
        if r['ticker'] == 'RNI':
            assert all(r[k] == '' for k in ['revenue_zar_raw', 'eps_zar_raw', 'earnings_yield_raw'])
            for column, key in [('revenue_zar_model', 'revenue_zar'), ('eps_zar_model', 'eps_zar'), ('earnings_yield_model_clipped', 'earnings_yield')]:
                assert math.isclose(float(r[column]), method['fundamental_imputation'][key])
        else:
            assert float(r['revenue_zar_model']) == float(r['revenue_zar_raw'])
            assert float(r['eps_zar_model']) == float(r['eps_zar_raw'])
            raw = float(r['earnings_yield_raw'])
            assert math.isclose(raw, float(r['eps_zar_raw']) / float(r['close_zar']), rel_tol=1e-9)
            bounds = method['earnings_yield_clipping']
            expected = max(bounds['lower'], min(bounds['upper'], raw))
            assert math.isclose(float(r['earnings_yield_model_clipped']), expected, rel_tol=1e-9)
    reconcile_workbook(rows, dates)
    print('PASS: 123 rows; 41 per date; 43 tickers; 3 RNI rows retained; 2 volume imputations; model features complete.')
    return {'derived_constants': derived, 'workbook_reconciled': True}


def reconcile_workbook(rows, dates):
    from audit_workbook import read_workbook
    sheets = read_workbook()
    columns = {'F': 'return_1y', 'H': 'market_cap_zar', 'I': 'beta_1y', 'K': 'shares_outstanding',
               'L': 'revenue_zar_raw', 'M': 'eps_zar_raw', 'N': 'annualised_volatility_1y',
               'O': 'dividend_yield', 'AR': 'close_zar', 'AT': 'earnings_yield_raw'}
    for date in dates:
        raw = sheets[date][1:]
        lookup = {next(v for k, v in r.items() if k.rstrip('0123456789') == 'B'): r for r in raw}
        selected = [r for r in rows if r['decision_date'] == date]
        assert set(lookup) == {r['ticker'] for r in selected}, ('Workbook membership mismatch', date)
        for r in selected:
            cells = {k.rstrip('0123456789'): v for k, v in lookup[r['ticker']].items()}
            assert cells.get('E', '') == '', 'Unavailable analyst ratings must remain blank'
            assert cells['D'] == r['sector_label']
            assert cells['AL'] == r['membership_evidence']
            for col, key in columns.items():
                source = cells.get(col, '')
                assert (source == '') == (r[key] == ''), (date, r['ticker'], key, 'Missingness mismatch')
                if source:
                    assert math.isclose(float(source), float(r[key]), rel_tol=1e-12, abs_tol=1e-12), (date, r['ticker'], key)
            volume = cells.get('G', '')
            assert (not volume) == (r['volume_imputed'] == 'true')
            if volume:
                assert math.isclose(float(volume), float(r['average_daily_volume_1y_model']), rel_tol=1e-12)
    for i, date in enumerate(dates):
        members = set()
        for row in sheets['Ticker Membership'][1:]:
            cells = {k.rstrip('0123456789'): v for k, v in row.items()}
            if cells[chr(ord('E')+i)] == '1':
                members.add(cells['A'])
        assert members == {r['ticker'] for r in rows if r['decision_date'] == date}


if __name__ == '__main__':
    validate()
